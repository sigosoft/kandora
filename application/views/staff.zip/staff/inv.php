<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Kandora boutique</title>

    <style>

    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }

    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }

    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }

    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }

    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }

    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }

    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }

    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }

    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }

    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }

    .invoice-box table tr.item.last td {
        border-bottom: none;
    }

    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }

    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }

        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }

    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }

    .rtl table {
        text-align: right;
    }

    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
		.text-center{
			text-align: center;
		}
		.col-12{
			width: 100%;
		}
		.col-6{
			width: 50%;
			float: left;
		}
    </style>
</head>

<body onload="window.print()">
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="1" class="col-12">
                        <tr>
                            <td class="text-center">
                                KANDORA BOUTIQUE<br>
                                ADDRESS<br>
                                MOBILE NUMBER<br>
                            </td>
                        </tr>
                </td>
            </tr>
            </table>
		<table cellpadding="0" cellspacing="0">
            <tr class="heading">
                <td>
                    Invoice # : <?=$invoice->invoice_id?>
                </td>

                <td>
                    Invoice Date : <?=$invoice->date?>
                </td>
            </tr>

            <tr class="details">
                    <td>
					<div class="col-6">Billed To :</div>
                     <div class="col-6"><?=$customer->customer_name?></div>
                    </td>

                <td>
                   <?=$customer->customer_location?>
                </td>
            </tr>
             </table>
		<table cellpadding="0" cellspacing="0">
            <tr class="heading">
                <td>
                    Item Name
                </td>
				        <td>
                    Total
                </td>
            </tr>

            <tr class="item">
                <td>
                    Name
                </td>
                <td>
                  <?=$customer->member_name?>
                </td>

            </tr>

            <tr class="item">
                <td>
                    Item
                </td>
                <td>
                  <?=$invoice->product?>
                </td>

            </tr>
            <tr class="item">
                <td>
                    Category
                </td>
                <td>
                  <?=$invoice->category?>
                </td>

            </tr>
            <tr class="item">
                <td>
                    Quantity
                </td>
                <td>
                  <?=$invoice->quantity?>
                </td>

            </tr>
            <tr class="item">
                <td>
                    Amount
                </td>
                <td>
                  <?=$invoice->total?>
                </td>
            </tr>
            <tr class="item last">
                <td>
                    VAT (5%)
                </td>
                <td>
                    <?=$invoice->vat?>
                </td>

            </tr>

            <tr class="total">
                <td></td>
                <td>
                   Total : <?=$invoice->grand_total?>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
