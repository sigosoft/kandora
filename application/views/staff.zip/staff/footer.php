<footer class="footer text-right">
    © Copyright 2018 - App name here
</footer>
